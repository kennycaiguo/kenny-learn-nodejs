

#helps finding erros in the code
grep -in --color --exclude=\*.min.* -r $1 ../src/.

