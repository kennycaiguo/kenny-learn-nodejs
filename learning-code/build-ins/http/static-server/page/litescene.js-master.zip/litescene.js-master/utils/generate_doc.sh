yuidoc ../src ../external/litegl.js -o ../doc
