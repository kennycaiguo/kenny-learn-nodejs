///@INFO: UNCOMMON
function GeoJSONtoMesh(o)
{
}

GeoJSONtoMesh.prototype.convert = function(geojson)
{
	var mesh = null;
	//
}


//LiteGraph Node


