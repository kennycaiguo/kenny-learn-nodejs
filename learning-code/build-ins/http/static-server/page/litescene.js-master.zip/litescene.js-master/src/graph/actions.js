//not used yet
//meant for triggers