
//导入jwt
let jwt = require('jsonwebtoken')
//从配置文件中获取密钥
let {secret} = require('../config/config')
// 定义token验证中间件
module.exports = (req,res,next)=>{
    //获取token
   let token = req.get('token')
   //判断token是否有值，需要处理没有值的情况
   if(!token){
       return res.json({
         code:'2003',msg:'token缺失',data:null
       })
   }
    //token校验
    jwt.verify(token,secret,(err,data)=>{
     if(err){
       return res.json({
         code:'2004',msg:'token校验失败',data:null
       })
     }
      //保存用户信息
      req.user = data

     //token校验成功，就放行
     next()
   }) 
 }