let mongoose = require('mongoose')

let userSchema = new mongoose.Schema({
    username:{
    type:String,
    required:true,
    unique:true
    },
   password:{
    type:String,
    required:true,
    }
})
//创建模型对象,bookModel就是对应books集合，她可以完成数据的增删改查
let userModel = mongoose.model("users",userSchema)

//导出模型对象
module.exports = userModel
