var express = require('express');
var router = express.Router();
//导入md5加密库用来加密用户密码
let md5 = require('md5')
//导入用户模型文件
let userModel = require('../../model/userModel')
//导入jwt
let jwt = require('jsonwebtoken')
//从配置文件中获取加密密钥
let {secret} = require('../../config/config')
//登录处理路由
router.post('/login',(req,res)=>{
  //获取用户名和密码
  let {username,password} = req.body
  let pwd = md5(password) //对密码进行md5加密
  //根据用户输入的信息到数据库里面查询改用户
  userModel.findOne({username:username,password:pwd})
     .then(data=>{
      // console.log(data);
       //需要判断如果没有查询到用户data是null，说明可能是用户名或者密码错误
       if(!data){
         return  res.json({
          code:'2002',
          msg:"用户名或者密码错误！！！",
          data:null
        })
      } 
        //创建token
       let token = jwt.sign(
          {
            username:data.username,
            _id:data._id
          },
          secret,
          {expiresIn:60*60*24*7} //设置7天有效，他的单位是秒
       )
        //响应token
        res.json({
          code:'0000',
          msg:'登录成功' ,
          data:token
        })
        res.render('success',{msg:"登录成功",url:"/account"})
      
     }).catch(err=>{
      res.json({
        code:'2001',
        msg:"数据库读取失败",
        data:null
      })
      return
    })      

})

//退出登录的路由处理，使用post方法可以防止跨站请求伪造
router.post('/logout',(req,res)=>{
  //销毁session
  req.session.destroy(()=>{
    //需要渲染成功页面
    res.render('success',{msg:'退出登录成功',url:"/login"})
  })
})
module.exports = router;

