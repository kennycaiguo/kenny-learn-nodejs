var express = require('express');
var router = express.Router();

//引入模型
let accountModel = require('../../model/accountModel')
//导入moment库
let moment = require('moment')
// console.log(moment('2023-02-23').toDate());//ok
//导入token验证中间件
let checkTokenMiddleware = require('../../middleware/checkTokenMiddleware')

//显示账本列表的路由，从数据库读取所有文档数据渲染到页面
router.get('/account',checkTokenMiddleware, function(req, res, next) {
  //获取所有账单信息,按时间倒序排列
    accountModel.find().sort({time:-1}).then(data=>{
      //api接口是返回json数据给客户端的，json数据有以下属性
      //1.code，通常是0000或者20000，建议使用0000注意这里不是http状态码
      //2.msg也就是信息
      //3.data也就是响应数据
      res.json({
        code:'0000',
        msg:'读取成功',
        data:data
      })
    }).catch(err=>{ 
      res.json({ 
          code:'1001',//json响应失败的状态码是1xxxx，如1001
          msg:'读取失败',
          data:null
      })
      return
    })
 
});

//新增账单的api
router.post('/account',checkTokenMiddleware, function(req, res) {
 
  //用mongodb保存数据
  accountModel.create({
      ...req.body,
      time:moment(req.body.time).toDate()
    })
   .then(data=>{
    res.json({
        code:'0000',
        msg:'插入数据成功',
        data:data
      })
   }).catch(err=>{
    res.json({ 
        code:'1002',//json响应失败的状态码是1xxxx，如1001
        msg:'插入数据失败',
        data:null
    })
    return
   })
  
});

//修改(更新)账单的api
router.patch('/account/:id',checkTokenMiddleware,function(req,res,next){
      let {id} = req.params
      accountModel.updateOne({_id:id},req.body)
      .then(data=>{
        //这里是默认的处理方式，他会返回一个统计对象，如果你不想要，就需要在下面做处理，获取你需要的数据
        // res.json({
        //   code:'0000',
        //   msg:'更新数据成功',
        //   data:data
        // })

       //由于我们需要更新后的数据，所以这里需要根据id查询数据,然后把结果返回
         accountModel.findById(id).then(data=>{
            res.json({
              code:'0000',
              msg:'更新数据成功',
              data:data
            })
         })
      }).catch(err=>{
        res.json({
          code:'1005',
          msg:'更新数据失败',
          data:null
        })
      })
})


//删除记录的api
router.delete('/account/:id', checkTokenMiddleware,function(req, res, next) {
  let id = req.params.id
  // console.log(id)
  //删除记录

  accountModel.deleteOne({_id:id}).then(data=>{
    res.json({
        code:'0000',
        msg:'删除数据成功',
        data:{}
      })
  }).catch(err=>{
    res.json({ 
        code:'1003',//json响应失败的状态码是1xxxx，如1001
        msg:'删除数据失败',
        data:null
    })
    return
  })
  
});

//获取一条账单的api接口
router.get('/account/:id',checkTokenMiddleware,function(req,res,next) {
  let id = req.params.id
  accountModel.findById({_id:id}).then(data=>{
            res.json({
              code:'0000',
              msg:'查询数据成功',
              data:data
          })
       }).catch(err=>{
        res.json({
          code:'1004',
          msg:'查询数据失败',
          data:null
      })
    })
})

module.exports = router;

