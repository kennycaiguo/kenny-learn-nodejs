var express = require('express');
var router = express.Router();
//导入md5加密库用来加密用户密码
let md5 = require('md5')
//导入用户模型文件
let userModel = require('../../model/userModel')
//用户注册表单页面路由
router.get('/reg',(req,res)=>{
  res.render('auth/reg')
}) 

//用户注册数据处理路由
router.post('/reg',(req,res)=>{
  //表单验证,以后慢慢完善，如不允许有两个名字相同的用户
   //获取表单数据
  //  console.log(req.body);
  
  userModel.create({
     ...req.body,
     password:md5(req.body.password)
  }).then(data=>{
    res.render('success',{msg:'注册成功',url:'/login'})
  }).catch(err=>{
    res.status(500).send("注册失败，请稍后再试")
    return
  })
}) 

//用户登录页面路由
router.get('/login',(req,res)=>{
  res.render('auth/login')
})
//登录处理路由
router.post('/login',(req,res)=>{
  //获取用户名和密码
  let {username,password} = req.body
  let pwd = md5(password) //对密码进行md5加密
  //根据用户输入的信息到数据库里面查询改用户
  userModel.findOne({username:username,password:pwd})
     .then(data=>{
      // console.log(data);
       //需要判断如果没有查询到用户data是null，说明可能是用户名或者密码错误
       if(!data){
         return res.send("用户名或者密码错误！！！")
        } 
        //写入session
        req.session.username = data.username
        req.session._is = data._id
        res.render('success',{msg:"登录成功",url:"/account"})
      
     }).catch(err=>{
      res.status(500).send("登录失败，请稍后再试")
      return
    })      
  // res.render('auth/login')
})

//退出登录的路由处理，使用post方法可以防止跨站请求伪造
router.post('/logout',(req,res)=>{
  //销毁session
  req.session.destroy(()=>{
    //需要渲染成功页面
    res.render('success',{msg:'退出登录成功',url:"/login"})
  })
})
module.exports = router;

