let jwt = require('jsonwebtoken')
//创建
let token = jwt.sign(
    {username:'xiaoming'},
    'atguigu',
    {expiresIn:60}
 )
//  解析
jwt.verify(token,'atguigu',(err,data)=>{
    if(err){
        console.log('校验失败');
        return
    }
    console.log(data);
})