//登录检测中间件
module.exports = (req,res,next)=>{
    //判断用户是否登录，如果没有就把引导到登录页面
  if(!req.session.username){
    return res.redirect('/login')
  }
  //如果用户登录了，就放行
  next()
}