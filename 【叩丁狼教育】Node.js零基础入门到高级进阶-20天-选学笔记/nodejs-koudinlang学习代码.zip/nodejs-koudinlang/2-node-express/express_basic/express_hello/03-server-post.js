//express处理get请求
let express = require('express')
let bodyParser = require('body-parser')
let app = express()
let PORT = 3002

app.get('/',(req,res)=>{
    res.send('<h1>Welcome to index</h1>')
})
app.get('/get_reg',(req,res)=>{
    console.log(req.query); 
    res.send('<h1>login</h1>')
})

//配置静态服务器
app.use(express.static('public'))
//配置404
app.get('*',(req,res)=>{ //如果我们没有为两个路径配置路由，就会被他匹配到
    res.send('<h1>Not Found</h1>')
})

//post方法
//1.需要利用bodyParser来生成一个能够解析表单数据的中间件
let urlParser = bodyParser.urlencoded({extended:false}) //false接收字符串或者数组，true接收任意类型
app.post('/post_reg',urlParser,(req,res)=>{ //2.使用解析表单数据的中间件
    // console.log(req.body);
    let {username,email,password} = req.body
    console.log(username,email,password);
    res.send(`<h4>welcome ${username}</h4>`)
})

app.listen(PORT,()=>{
    console.log(`url: http://localhost:${PORT}/`);
})

