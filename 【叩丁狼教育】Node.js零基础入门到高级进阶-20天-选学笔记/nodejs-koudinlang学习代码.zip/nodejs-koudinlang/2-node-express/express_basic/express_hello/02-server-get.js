//express处理get请求
let express = require('express')

let app = express()
let PORT = 3001

app.get('/',(req,res)=>{
    res.send('<h1>Welcome to index</h1>')
})
app.get('/get_reg',(req,res)=>{
    console.log(req.query); 
    res.send('<h1>login</h1>')
})

//配置静态服务器
app.use(express.static('public'))
//配置404
app.get('*',(req,res)=>{ //如果我们没有为两个路径配置路由，就会被他匹配到
    res.send('<h1>Not Found</h1>')
})

app.listen(PORT,()=>{
    console.log(`url: http://localhost:${PORT}/`);
})

