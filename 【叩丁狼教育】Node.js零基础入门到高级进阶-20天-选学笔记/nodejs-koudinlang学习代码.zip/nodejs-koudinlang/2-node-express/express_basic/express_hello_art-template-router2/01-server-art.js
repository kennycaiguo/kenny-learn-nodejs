//express art-template的使用
let path = require('path')
let express = require('express')
let bodyParser = require('body-parser')
let app = express()
let PORT = 3004

//导入首页路由文件
let indexRouter = require('./routes/index')
let passportRouter = require('./routes/passport')

//设置art-template引擎,4个步骤
//1.引入art-template,使用对应的引擎
app.engine('html',require('express-art-template'))
//2.设置项目环境
app.set('view options',{
    debug:process.env.NODE_ENV!== "production"
})
//3.设置视图路径，也就是到哪里找模板文件
app.set('views',path.join(__dirname,'views'))
//4.设置模板文件的后缀名
app.set('view engine','html')

//配置静态资源服务器
app.use(express.static('public'))

app.use(indexRouter) //全局注册路由文件

//配置404
app.get('*',(req,res)=>{ //如果我们没有为两个路径配置路由，就会被他匹配到
    res.send('<h1>Not Found</h1>')
})

//post方法
//1.需要利用bodyParser来生成一个能够解析表单数据的中间件
let urlParser = bodyParser.urlencoded({extended:false}) //false接收字符串或者数组，true接收任意类型
// //2.全局注册解析表单数据的中间件
app.use(urlParser) //使用路由文件导出的注册路由
app.use(bodyParser.json())   // 解析json格式
 
//全局注册passportRouter
app.use(passportRouter)

app.listen(PORT,()=>{
    console.log(`url: http://localhost:${PORT}/`);
})

