let express = require('express')
let path = require('path')
let port = 3000
let app = express()

//处理中文乱码
app.use(function (req, res, next) {
    res.setHeader('Content-Type', 'text/html;charset=utf-8');
    next();
});
//配置模板引擎,4步，一个engine和3个set
app.engine('html',require('express-art-template'))
app.set('view options',{
    debug:process.env.NODE_ENV!=='production'
})
app.set('views',path.join(__dirname,'views'))
app.set('view engine','html') 

//app.use(express.static(__dirname+'/public'))//静态服务器，根据需要配置
app.get('/',(req,res)=>{
     res.end('<a href="/list">new list</a>')
})
app.get('/list',(req,res)=>{
     res.render('list') //渲染列表页面
})

//响应动态路由
app.get('/detail/:id/:type',(req,res)=>{
    let {id,type} = req.params
    res.end(`<h1>第${id}条新闻标题</h1> <hr> <h3>主题是：${type}</h3>`)
})

app.listen(port,()=>{
     console.log('server is ready :http://localhost:'+port+'/');
})

