//express art-template的使用
let path = require('path')
let express = require('express')
let bodyParser = require('body-parser')
let app = express()
let PORT = 3003

//模拟登录用数据
let USER = 'admin'
let PASS = '12345' 

//设置art-template引擎,4个步骤
//1.引入art-template,使用对应的引擎
app.engine('html',require('express-art-template'))
//2.设置项目环境
app.set('view options',{
    debug:process.env.NODE_ENV!== "production"
})
//3.设置视图路径，也就是到哪里找模板文件
app.set('views',path.join(__dirname,'views'))
//4.设置模板文件的后缀名
app.set('view engine','html')

//配置静态资源服务器
app.use(express.static('public'))

app.get('/',(req,res)=>{
    let data=[
        {name:'登录',href:"/login.html"},
        {name:'注册',href:"/register.html"},
    ]
    res.render('index',{data}) //渲染首页
})


//配置404
app.get('*',(req,res)=>{ //如果我们没有为两个路径配置路由，就会被他匹配到
    res.send('<h1>Not Found</h1>')
})

//post方法
//1.需要利用bodyParser来生成一个能够解析表单数据的中间件
let urlParser = bodyParser.urlencoded({extended:false}) //false接收字符串或者数组，true接收任意类型
// //2.全局注册解析表单数据的中间件
app.use(urlParser)
app.post('/register',(req,res)=>{
    // console.log(req.body);
    let {username,email,password} = req.body
    console.log(username,email,password);
    
    //业务逻辑：
    //校验数据，是否为空，是否符合规定
    //查询数据库看看用户名是否已经被注册了
    //...
    //假设数据已经通过上面的校验了，用户成功注册，现在需要跳转到登录页面
    res.redirect('/login.html')//路由重定向
})

app.post('/login',(req,res)=>{//模拟登录处理
    // console.log(req.body);
    let {username,password} = req.body
    console.log(username,password);
    if(username != USER || password != PASS){
        res.send(`登录失败，用户名或者密码错误！！！`)
        return
    }
    res.send(`<h4>登录成功，欢迎 ${username}</h4>`)
})

app.listen(PORT,()=>{
    console.log(`url: http://localhost:${PORT}/`);
})

