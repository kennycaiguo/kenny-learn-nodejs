let express = require('express')

//模拟登录用数据
let USER = 'admin'
let PASS = '12345' 

let router = express.Router()

 router.post('/',(req,res)=>{//模拟登录处理
    // console.log(req.body);
    let {username,password} = req.body
    console.log(username,password);
    if(username != USER || password != PASS){
        res.send(`登录失败，用户名或者密码错误！！！`)
        return
    }
    res.send(`<h4>登录成功，欢迎 ${username}</h4>`)
})

module.exports = router