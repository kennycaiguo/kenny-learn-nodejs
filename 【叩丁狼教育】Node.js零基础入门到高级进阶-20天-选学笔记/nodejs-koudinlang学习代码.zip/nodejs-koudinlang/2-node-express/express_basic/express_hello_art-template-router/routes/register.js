let express = require('express')

let router = express.Router()

 router.post('/',(req,res)=>{
    // console.log(req.body);
    let {username,email,password} = req.body
    console.log(username,email,password);
    
    //业务逻辑：
    //校验数据，是否为空，是否符合规定
    //查询数据库看看用户名是否已经被注册了
    //...
    //假设数据已经通过上面的校验了，用户成功注册，现在需要跳转到登录页面
    res.redirect('/login.html')//路由重定向
})

module.exports = router