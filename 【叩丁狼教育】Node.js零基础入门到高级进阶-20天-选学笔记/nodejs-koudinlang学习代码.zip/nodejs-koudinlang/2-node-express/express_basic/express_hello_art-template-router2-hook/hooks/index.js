//测试用的钩子函数
function checkLogin(req,res,next){
    console.log("使用路由组件之前，登录检测...");
    next() //必须调用，否则后面代码无法执行
}

//导出
module.exports = {checkLogin}