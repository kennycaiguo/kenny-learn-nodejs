let express = require('express')

let router = express.Router()

router.get('/',(req,res)=>{
    let data=[
        {name:'登录',href:"/login.html"},
        {name:'注册',href:"/register.html"},
    ]
    res.render('index',{data}) //渲染首页
})

module.exports = router