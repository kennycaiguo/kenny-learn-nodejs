let express = require('express')
let router = express.Router()

//模拟登录用数据
let USER = 'admin'
let PASS = '12345' 


router.post('/register',(req,res)=>{ //这里必须使用/register因为此时在app里面没有做路由匹配
    // console.log(req.body);
    let {username,email,password} = req.body
    console.log(username,email,password);
    
    //业务逻辑：
    //校验数据，是否为空，是否符合规定
    //查询数据库看看用户名是否已经被注册了
    //...
    //假设数据已经通过上面的校验了，用户成功注册，现在需要跳转到登录页面
    res.redirect('/login.html')//路由重定向
})

router.post('/login',(req,res)=>{//模拟登录处理 //这里必须使用/login因为此时在app里面没有做路由匹配
    // console.log(req.body);
    let {username,password} = req.body
    console.log(username,password);
    if(username != USER || password != PASS){
        res.send(`登录失败，用户名或者密码错误！！！`)
        return
    }
    res.send(`<h4>登录成功，欢迎 ${username}</h4>`)
})

module.exports = router