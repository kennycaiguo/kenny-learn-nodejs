let express = require('express')
const { template } = require('express-art-template')
let cookieParser = require('cookie-parser')
let cookieSession = require('cookie-session')

let path = require('path')
let port = 3500
let app = express()

//全局注册cookieParser中间件,注意：有的中间件需要小括号，有的中间件不需要
app.use(cookieParser()) 
//全局注册cookieSession中间件
app.use(cookieSession({
    name:'my_session',
    keys:['adefg%%78$$','o9l1##dd09=='] ,//这个其实就是加密用的盐
    maxAge:2*24*1000*60*60 //过期时间为2天
}))
app.use(express.static(__dirname+'/public'))//静态服务器，根据需要配置

//定义art-template过滤器
//1.首字母大写过滤器
template.defaults.imports.Cap = (data)=>{
    if(data){
        return data.substring(0,1).toUpperCase()+data.substring(1)
    }
}

//时间戳变为"yyyy-MM-dd hh:mm:ss" 格式的时间字符串过滤器
template.defaults.imports.dateFormat = (timestamp)=>{
    let date = new Date(timestamp)
    console.log(date);
    let year = date.getFullYear()
    let month = (date.getMonth()+1).toString().padStart(2,'0')
    let day = date.getDay().toString().padStart(2,'0')
    let h = date.getHours().toString().padStart(2,'0')
    let m = date.getMinutes().toString().padStart(2,'0')
    let s = date.getSeconds().toString().padStart(2,'0')
    return `${year}-${month}-${day} ${h}:${m}:${s}`
}

//处理中文乱码
app.use(function (req, res, next) {
    res.setHeader('Content-Type', 'text/html;charset=utf-8');
    next();
});

//配置模板引擎,4步，一个engine和3个set
app.engine('html',require('express-art-template'))
app.set('view options',{
    debug:process.env.NODE_ENV!=='production'
})
app.set('views',path.join(__dirname,'views'))
app.set('view engine','html') 


app.get('/',(req,res)=>{
     res.render('index',{title:"模板继承例子",link:'/list'})
})
app.get('/list',(req,res)=>{
     res.render('list') //渲染列表页面
})

//测试过滤器的路由
app.get('/testfilter',(req,res)=>{
    res.render('test',{msg: 'hello',tstamp:1699978584726})
})
//响应动态路由
app.get('/detail/:id/:type',(req,res)=>{
    let {id,type} = req.params
    res.end(`<h1>第${id}条新闻标题</h1> <hr> <h3>主题是：${type}</h3>`)
})

//处理设置cookie的路由
app.get('/set_cookie',(req,res)=>{
    res.cookie('name','node',{maxAge:1000*60*60*2})
    res.cookie('age',11)
    res.send("设置了cookie")
})
app.get('/get_cookie',(req,res)=>{
    // console.log(req.cookies); //注意：这里是cookies
    // res.send(`获取到cookie数据${JSON.stringify(req.cookies)}`)
    res.send(`获取到cookie数据,name:${req.cookies['name']},age:${req.cookies['age']}`)
})
//设置session的路由
app.get('/set_session',(req,res)=>{
    req.session['name'] = 'session_node'
    req.session['age'] = 20
    
   res.send('成功设置了session数据')
})

//获取session的路由
app.get('/get_session',(req,res)=>{
    let name = req.session['name'] 
    let  age = req.session['age']
    
   res.send(`获取session数据，name:${name},age:${age}`)
})

app.listen(port,()=>{
     console.log('server is ready :http://localhost:'+port+'/');
})

