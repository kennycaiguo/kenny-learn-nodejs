let path = require('path')
let express = require('express')
let bodyParser = require('body-parser') //导入bodyParser中间件

let db = require('./db/nodejs-orm/index') //导入orm模块
let orm_config = require('./config/config') //导入数据库配置

let port = 3000
let app = express()
//注册bodyParser中间件
app.use(bodyParser.urlencoded({extended:false}))
//app.use(express.static(__dirname+'/public'))//静态服务器，根据需要配置

//配置模板引擎和视图路径
app.engine('html',require('express-art-template'))
app.set('view options',{
    debug: process.env.NODE_ENV!='production'
})
app.set('views',path.join(__dirname,'views'))
app.set('view engine','html')

app.get('/',(req,res)=>{
     res.render('index')
})

//连接数据库
db.connect(orm_config)
//创建学生模型
let stuModel = db.model('students')

//获取学生列表的路由
app.get('/get_data',(req,res)=>{
    //查询所有,其实就是查询所有is_deleted=0的学生is_deleted=1就相当于删除了,不能做任何处理
    stuModel.find('is_deleted=0',(err,data)=>{
        res.render('student-list',{students:data})
    })
})
//显示学生详情信息的路由
app.get('/student_detail/:id',(req,res)=>{

    let id = req.params.id
    // let sql = 'select * from students where id=' + id +";"
    // //查询数据库，返回到浏览器
    
    stuModel.find('id='+id,(err,data)=>{
        res.render('detail',{students:data})
    })

   
})

//渲染新增学生页面
app.get('/new',(req,res)=>{
    res.render('new')
})

//实现新增学生功能的路由
app.post('/add_stu',(req,res)=>{
    // console.log(req.body);
    //获取表单数据
    let stu = req.body
    stuModel.insert(stu,(err,data)=>{
       if(err){
        console.log(err);
        return
       }
       res.redirect('/get_data')
    })
   
})

//根据动态路由:id获取到学生id然后查询数据渲染edit页面
app.get('/edit_student/:id',(req,res)=>{
    let id = req.params.id //获取id
    //根据id查询学生学习
    stuModel.find("id="+id,(err,data)=>{
        if(err){
            console.log(err);
            return;
        }
        res.render('edit.html',{student:data[0]}) //虽然数据是一个数组但是它只有一个元素,可以用下标0来获取
    })
    
}) 

//将修改后的学生信息更新到数据库
app.post('/edit_student',(req,res)=>{
    let student = req.body //获取表单数据
    //注意学生的id必须使用一个hidden字段传递过来
    //更新学生信息
    stuModel.update('id='+student.id,student,(err,data)=>{
        if(err){
            console.log(err);
            return;
        }
        res.redirect('/get_data')
    })
   
    
})

//删除学生信息,其实就是给这个学生信息的is_delete设置为1
app.get('/delete_student/:id',(req,res)=>{
    let id = req.params.id //获取id
    //根据id查询学生学习
    stuModel.update('id='+id,{is_deleted:1},(err,data)=>{
        if(err){
            console.log(err);
            return;
        }
        res.redirect('/get_data')
    })
    
}) 

app.listen(port,()=>{
     console.log('server is ready :http://localhost:'+port+'/');
})


