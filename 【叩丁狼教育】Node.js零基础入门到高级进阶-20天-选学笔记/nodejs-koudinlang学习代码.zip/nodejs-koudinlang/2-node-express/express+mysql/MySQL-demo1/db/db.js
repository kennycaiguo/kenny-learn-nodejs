let mysql = require('mysql')

//创建连接池
let pool = mysql.createPool({
    host:'localhost',
    user:'root',
    password:'root',
    database:'qd22'
})

function query(sql,callback){
    pool.getConnection(function(err,connection){
        connection.query(sql,function(err,rows){
            callback(err,rows)
            connection.release()
        })
    })
}

exports.query = query