let path = require('path')
let express = require('express')
let db = require('./db/db') //导入db模块

let port = 3000
let app = express()
//app.use(express.static(__dirname+'/public'))//静态服务器，根据需要配置

//配置模板引擎和视图路径
app.engine('html',require('express-art-template'))
app.set('view options',{
    debug: process.env.NODE_ENV!='production'
})
app.set('views',path.join(__dirname,'views'))
app.set('view engine','html')

app.get('/',(req,res)=>{
     res.render('index')
})
//获取学生列表的路由
app.get('/get_data',(req,res)=>{
    //查询数据库，返回到浏览器
    db.query('select * from students;',function(err,rows){
        // console.log(rows);
        res.render('student-list',{students:rows})
    })

})
//显示学生详情信息的路由
app.get('/student_detail/:id',(req,res)=>{

    let id = req.params.id
    let sql = 'select * from students where id=' + id +";"
    //查询数据库，返回到浏览器
    db.query(sql,function(err,rows){
        // console.log(rows);
        res.render('detail',{students:rows})
    })
   
})

app.listen(port,()=>{
     console.log('server is ready :http://localhost:'+port+'/');
})


