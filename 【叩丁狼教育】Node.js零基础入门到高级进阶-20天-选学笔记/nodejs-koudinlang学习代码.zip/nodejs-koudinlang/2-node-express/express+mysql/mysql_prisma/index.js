let {PrismaClient} = require('@prisma/client')

let client  = new PrismaClient()


let stus = client.student.createMany({
    data:[
        {name:'刘德华',age:16,height:180.00,gender:'Male',clsId:2,isDeleted:0},
        {name:'蔡依林',age:16,height:170.00,gender:'Female',clsId:1,isDeleted:0},
        {name:'Brandy',age:17,height:160.00,gender:'Female',clsId:2,isDeleted:0},
        {name:'Tracy',age:15,height:172.00,gender:'Female',clsId:1,isDeleted:0},
    ]
})

stus.then(data=>console.log(data))

// let newStudent = client.student.create({
//     data:{
//         name : 'xiaoming',
//         age : 14,
//         height: 172.30,
//         gender: 'Male',
//         clsId: 0,
//         isDeleted: 0
//   },
// });
// newStudent.then((data)=>console.log(data))

// let newStudent2 = client.student.create({
//     data:{
//         name : 'xiaohong',
//         age : 15,
//         height: 166.30,
//         gender: 'Female',
//         clsId: 1,
//         isDeleted: 0
//   },
// });
// newStudent2.then((data)=>console.log(data))

// let newStudent2 = client.student.create({
//     data:{
//         name : 'xiaowang',
//         age : 15,
//         height: 169.00,
//         gender: 'Male',
//         clsId: 1,
//         isDeleted: 0
//   },
// });

// newStudent2.then((data)=>console.log(data))

