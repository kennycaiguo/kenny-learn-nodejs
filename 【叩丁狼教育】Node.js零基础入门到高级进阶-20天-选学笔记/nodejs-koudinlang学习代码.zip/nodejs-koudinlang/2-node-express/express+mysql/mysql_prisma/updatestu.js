let {PrismaClient} = require('@prisma/client')

let client = new PrismaClient()

let res = client.student.update({
    where:{id:8,name:'Tracy',},
    data:{age:14,},
})

res.then(data=>{
    console.log(data);
})

