let {PrismaClient} = require('@prisma/client')

let client = new PrismaClient()

let del = client.student.delete({where:{id:8}})
del.then(data=>{
    console.log(data);
})

//deleteMany就是删除多条符合条件的记录