let {PrismaClient} =require('@prisma/client')

let client = new PrismaClient()

//查找所有学生
// client.student.findMany().then(stus=>{
//     console.log(stus); 
// }) //ok

// //根据id查找学生
// client.student.findFirst({where:{id:3}}).then(stu=>{
//     console.log(stu);
// })

//根据姓名查询一个学生
// client.student.findFirst({where:{name:'Tracy'}}).then(stu=>{
//         console.log(stu); //ok
// })
    
//根据性别查询多个学生
   client.student.findMany({where:{gender:'Female'}}).then(data=>{
      console.log(data);
   })