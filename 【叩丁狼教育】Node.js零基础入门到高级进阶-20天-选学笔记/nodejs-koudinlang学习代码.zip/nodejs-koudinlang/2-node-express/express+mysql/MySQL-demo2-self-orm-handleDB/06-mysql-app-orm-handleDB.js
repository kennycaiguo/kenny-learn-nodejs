let path = require('path')
let express = require('express')
let bodyParser = require('body-parser') //导入bodyParser中间件

let db = require('./db/nodejs-orm/index') //导入orm模块
let orm_config = require('./config/config') //导入数据库配置
let handleDB = require('./db/handleDB.js') //导入自己写的数据库通用操作函数

let port = 3001
let app = express()
//注册bodyParser中间件
app.use(bodyParser.urlencoded({extended:false}))
//app.use(express.static(__dirname+'/public'))//静态服务器，根据需要配置

//配置模板引擎和视图路径
app.engine('html',require('express-art-template'))
app.set('view options',{
    debug: process.env.NODE_ENV!='production'
})
app.set('views',path.join(__dirname,'views'))
app.set('view engine','html')

app.get('/',(req,res)=>{
     res.render('index')
})

//连接数据库
db.connect(orm_config)
//创建学生模型
// let stuModel = db.model('students')

//获取学生列表的路由
app.get('/get_data',(req,res)=>{
    (async function get_data(){
        let result = await handleDB(res,'students','find','查询数据错误','is_deleted=0')
        res.render('student-list',{students:result})   
    })() //立即调用函数
})
//显示学生详情信息的路由
app.get('/student_detail/:id',(req,res)=>{

    (async function(){
        let id = req.params.id
        let result = await handleDB(res,'students','find','查询数据错误','id='+id)
        res.render('detail',{students:result})
    })()
   
})

//渲染新增学生页面
app.get('/new',(req,res)=>{
    res.render('new')
})

//实现新增学生功能的路由
app.post('/add_stu',(req,res)=>{
    (async function(){
        let student = req.body
        await handleDB(res,'students','insert',"插入数据错误",student,) 
        res.redirect('/get_data')
    })()

})

//根据动态路由:id获取到学生id然后查询数据渲染edit页面
app.get('/edit_student/:id',(req,res)=>{
   
    (async function(){
        //获取id
        let id = req.params.id
        let result = await handleDB(res,'students','find','查询数据错误',"id="+id)
        res.render('edit.html',{student:result[0]}) //虽然数据是一个数组但是它只有一个元素,可以用下标0来获取
    })()
  
}) 

//将修改后的学生信息更新到数据库
app.post('/edit_student',(req,res)=>{
   (async function(){
      let student = req.body
      await handleDB(res,'students','update','更新数据错误','id='+student.id,student)
      res.redirect('/get_data')
   })()
    
})

//删除学生信息,其实就是给这个学生信息的is_delete设置为1
app.get('/delete_student/:id',(req,res)=>{
    (async function(){
        let id = req.params.id
        await handleDB(res,'students','update','删除数据错误','id='+id,{is_deleted:1}) 
        res.redirect('/get_data')
    })()
}) 

app.listen(port,()=>{
     console.log('server is ready :http://localhost:'+port+'/');
})


