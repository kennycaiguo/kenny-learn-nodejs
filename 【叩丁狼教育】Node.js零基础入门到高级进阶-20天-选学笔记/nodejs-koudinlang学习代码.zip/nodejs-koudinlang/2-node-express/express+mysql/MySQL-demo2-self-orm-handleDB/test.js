let handleDB = require('./db/handleDB.js')

handleDB()