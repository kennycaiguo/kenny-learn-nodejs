//封装数据库操作到一个方法中，使他成为通用方法
let db = require('./nodejs-orm/index')

/**
 * 
 * @param {*} res 服务器的响应对象
 * @param {*} tableName 需要处理的表名
 * @param {*} methodName 操作方法如find，insert，update，delete等等
 * @param {*} errMsg 错误信息必须放在n1和n2前面，否则报错因为n1和n2必须放最后
 * @param {*} n1 回调函数前面的第一个参数，是可选的
 * @param {*} n2 回调函数前面的第二个参数，也是可选的
 * @returns  返回操作结果
 * 需要根据n1和n2来确定操作方式，更新是n1和n2都不为undefined，insert是只需要n1，n2可以为undefine(也就是不传给它)，如果n1和n2
 * 都为undefined，可以做查询所有数据的操作或者删除所有数据的操作
 */
async function handleDB(res,tableName,methodName,errMsg,n1,n2){
//    console.log("handleDB test...");
    let Model = db.model(tableName)
    
    try {
        result =await new Promise((resolve,reject)=>{
        if(!n1){ //连n1都没有传递，n2肯定也是undefined，此时做查询全部或者删除全部的操作
             Model[methodName]('is_deleted=0',(err,data)=>{
            if(err){
                reject(err)
            }
            resolve(data)
            })

            return //做完一个查询后，需要返回
        } 
        //如果代码能够执行到这里，说明有n1了，我们需要判断n2有没有
        if(!n2){
            Model[methodName](n1,(err,data)=>{
                if(err){
                    reject(err)
                }
                resolve(data)
            })

            return
        } 
        //如果代码能够执行到这里，说明有n1和n2了
        Model[methodName](n1,n2,(err,data)=>{
            if(err){
                reject(err)
            }
            resolve(data)
        }) 
       
     })
    } catch (error) {
        console.log(error);
        res.send({errMsg:errMsg})
        return;
    }
  return result 
}

module.exports = handleDB