let express = require('express')
let cookieParser = require('cookie-parser')
let cookieSession = require('cookie-session')
let bodyParser = require('body-parser')

let path = require('path')
let port = 3500
//创建路由对象
let router = express.Router()
let app = express()


//全局注册bodyParser中间件
app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())
//全局注册cookieParser中间件,注意：有的中间件需要小括号，有的中间件不需要
app.use(cookieParser()) 
//全局注册cookieSession中间件
app.use(cookieSession({
    name:'my_session',
    keys:['adefg%%78$$','o9l1##dd09=='] ,//这个其实就是加密用的盐
    maxAge:2*24*1000*60*60 //过期时间为2天
}))
app.use(express.static(__dirname+'/public'))//静态服务器，根据需要配置

//处理中文乱码
app.use(function (req, res, next) {
    res.setHeader('Content-Type', 'text/html;charset=utf-8');
    next();
});

//配置模板引擎,4步，一个engine和3个set
app.engine('html',require('express-art-template'))
app.set('view options',{
    debug:process.env.NODE_ENV!=='production'
})
app.set('views',path.join(__dirname,'views'))
app.set('view engine','html') 

//编写一个能够随机生成token的函数
function getRandomString(n){
    let str = ''
    while(str.length<n){
        str += Math.random().toString(36).substring(2)
    }
    return str.substring(str.length-n) //注意这里其实就是从0开始截取到最后
}

router.all('/',(req,res)=>{
     if(req.method=="GET"){
        // console.log(getRandomString(48));
        res.render('login')
     }else if(req.method=="POST"){
         //注意：csrf防护我们以及在中间件里面做了，这里就不需要写防护代码了
         //获取用户名，密码
         let {username,pwd} = req.body
         console.log(username,pwd);
         //模拟数据库数据验证
         if(username === 'admin' && pwd === '12345'){
               //验证成功,需要设置状态保持，用来在其他路由验证用户是否登录
               req.session['username'] = username
               //转到transfer路由
            //    res.redirect('/transfer')
            res.json({code:200})
         } else{
            // res.send("用户名或者密码错误！！！")
            res.json({code:20000,errMsg:'用户名或者密码错误！！！'})
         }
      
     }
})


//转账路由,需要设置csrf_token
router.all('/transfer',(req,res)=>{
     //验证用户是否登录,必须一上来就做，无论用户是get还是post请求都需要登录验证
    let username = req.session['username']
    if(!username){ //用户没有登录
        //重定向到首页执行登录操作
        res.redirect('/')
    } 
    //功能进入这里，说明用户已经登录了
    if(req.method=="GET"){
        //产生csrf_token并且设置到cookie
        // res.cookie('csrf_token',getRandomString(48))
        res.render('transfer') //渲染转帐页面
    }else if(req.method=="POST"){
        // //模拟转账,
        //注意：csrf防护我们以及在中间件里面做了，这里就不需要写防护代码了
        let {account,money} = req.body
        
        //模拟转换成功，在后输出信息
        console.log(`成功给${account}转账${money}元`);
        res.json({account,money})
    }
    
})

router.get('/done',(req,res)=>{
    res.render('done')
})
//csrf中间件函数
function csrfProtect(req,res,next){
    if(req.method==='GET'){//在get方法颁发token
        //颁发csrf_token,使用res对象
        res.cookie('csrf_token',getRandomString(48))
        next()
    }
    else if(req.method==='POST'){
        let csrf_token = req.cookies['csrf_token'] //获取cookie中的token
        // let x_csrf_token = req.get('X-CSRFToken') //获取请求头中的token
        //获取请求头中的token写法2,cookie-parser会把heder里面的键全部转为小写
        let x_csrf_token = req.headers['x-csrftoken'] 
        // console.log(csrf_token,x_csrf_token);
        //然后进行比较验证他们是否是同一个token
         if(csrf_token!==x_csrf_token){
            //如果不相等，说明是csrf伪造请求，必须终止代码继续往下执行
            res.json('csrf_token验证失败,转账无法进行,去检查你的token')
            return
         } else{
            next()
         }  
    } 
}
//注册路由对象，注意需要先完成router所有功能的编写，然后再注册router，否则会报错
app.use(csrfProtect,router)

app.listen(port,()=>{
     console.log('server is ready :http://localhost:'+port+'/');
})

