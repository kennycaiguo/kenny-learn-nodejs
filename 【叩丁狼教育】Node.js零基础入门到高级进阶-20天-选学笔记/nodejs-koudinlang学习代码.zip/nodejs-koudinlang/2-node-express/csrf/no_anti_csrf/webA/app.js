let express = require('express')
let cookieParser = require('cookie-parser')
let cookieSession = require('cookie-session')
let bodyParser = require('body-parser')

let path = require('path')
let port = 3500
let app = express()

//全局注册bodyParser中间件
app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())
//全局注册cookieParser中间件,注意：有的中间件需要小括号，有的中间件不需要
app.use(cookieParser()) 
//全局注册cookieSession中间件
app.use(cookieSession({
    name:'my_session',
    keys:['adefg%%78$$','o9l1##dd09=='] ,//这个其实就是加密用的盐
    maxAge:2*24*1000*60*60 //过期时间为2天
}))
app.use(express.static(__dirname+'/public'))//静态服务器，根据需要配置

//处理中文乱码
app.use(function (req, res, next) {
    res.setHeader('Content-Type', 'text/html;charset=utf-8');
    next();
});

//配置模板引擎,4步，一个engine和3个set
app.engine('html',require('express-art-template'))
app.set('view options',{
    debug:process.env.NODE_ENV!=='production'
})
app.set('views',path.join(__dirname,'views'))
app.set('view engine','html') 


app.all('/',(req,res)=>{
     if(req.method=="GET"){
        res.render('login')
     }else if(req.method=="POST"){
         //获取用户名，密码
         let {username,pwd} = req.body
         console.log(username,pwd);
         //模拟数据库数据验证
         if(username === 'admin' && pwd === '12345'){
               //验证成功,需要设置状态保持，用来在其他路由验证用户是否登录
               req.session['username'] = username
               //转到transfer路由
               res.redirect('/transfer')
         } else{
            res.send("用户名或者密码错误！！！")
         }
      
     }
})


//转账路由
app.all('/transfer',(req,res)=>{
     //验证用户是否登录,必须一上来就做，无论用户是get还是post请求都需要登录验证
    let username = req.session['username']
    if(!username){ //用户没有登录
        //重定向到首页执行登录操作
        res.redirect('/')
    } 
    //功能进入这里，说明用户已经登录了
    if(req.method=="GET"){
        res.render('transfer') //渲染转帐页面
    }else if(req.method=="POST"){
        //模拟转账
        let {account,money} = req.body
        //模拟转换成功，在后输出信息
        console.log(`成功给${account}转账${money}元`);
        res.json({account,money})
    }
    
})

app.listen(port,()=>{
     console.log('server is ready :http://localhost:'+port+'/');
})

