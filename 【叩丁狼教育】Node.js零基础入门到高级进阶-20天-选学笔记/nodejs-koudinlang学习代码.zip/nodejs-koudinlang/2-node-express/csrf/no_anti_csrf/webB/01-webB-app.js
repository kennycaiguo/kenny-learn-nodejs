let express = require('express')
let path = require('path')
let port = 3600
let app = express()

//配置模板引擎,4步，一个engine和3个set
app.engine('html',require('express-art-template'))
app.set('view options',{
    debug:process.env.NODE_ENV!=='production'
})
app.set('views',path.join(__dirname,'views'))
app.set('view engine','html') 


app.all('/',(req,res)=>{
    res.render('index')
})

app.listen(port,()=>{
     console.log('server is ready :http://localhost:'+port+'/');
})

