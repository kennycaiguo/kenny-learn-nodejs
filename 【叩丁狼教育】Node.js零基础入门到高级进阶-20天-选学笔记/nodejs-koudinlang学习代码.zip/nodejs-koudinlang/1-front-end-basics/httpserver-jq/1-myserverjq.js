let http = require('http')
let fs = require('fs')
let path = require('path')

let PORT = 8082
//定义两个数据用来模拟数据库的记录，如果post传递过来的数据和这两个数据一样，就算是登录成功
const USER = "admin"
const PASS = '12345'

function doResponse(response,dir,fileName){
    let filePath = path.join(__dirname,'assets',dir,fileName)
    let content = fs.readFileSync(filePath)
    response.end(content)
}

let server = http.createServer((request,response)=>{
    //判断浏览器需要哪个资源
    let reqUrl = request.url
    if(reqUrl==='/' || reqUrl==='/index.html'){
        //读取页面内容,返回信息
        doResponse(response,"html","index.html")
    } else if(reqUrl==='/detail.html'){
        //读取页面内容,返回信息
        doResponse(response,"html","detail.html")
    } else if(reqUrl==='/login.html'){ //处理/login.html

       //读取页面内容,返回信息
        doResponse(response,"html",'login.html')

     }
     // else if(reqUrl==='/get_data'){ //处理/get_data
    //     let data = {
    //         "name":"kenny",
    //         "position":"boss"
    //     }
    //     response.end(JSON.stringify(data))
    // }
    else if(reqUrl.startsWith('/get_data')){ //处理/get_data+Math.random()
            let data = {
                "name":"kenny",
                "position":"boss"
            }
            response.end(JSON.stringify(data))
        }
      else if(reqUrl==='/login'){ //处理/login
        // console.log(request);
        let data = ''
        request.on('data',(chunk)=>{ //nodejs请求对象处理post添加的数据的方法，需要配合下面的end数件
            data += chunk
        })
        request.on('end',()=>{
            // console.log(data);
            let { username,pwd } = JSON.parse(data)
            // console.log(username,pwd);
            //利用上面定义的两个常量来模拟用户验证
            if(username === USER && pwd === PASS){
                response.end(`登录成功：欢迎您:${username}`)
            } else {
                response.end("登录失败，用户名或密码错误")
            }
            
        })
        
    } else if(reqUrl.endsWith('.css')){
        //读取页面内容,返回信息
       doResponse(response,'css','index.css')
    } else {
         response.setHeader('Content-type','text/html;charset=utf-8') 
         response.end('Page Not Found')
    }

})

server.listen(PORT,()=>{
    console.log(`server is ready at : http://localhost:${PORT}/`);
})
