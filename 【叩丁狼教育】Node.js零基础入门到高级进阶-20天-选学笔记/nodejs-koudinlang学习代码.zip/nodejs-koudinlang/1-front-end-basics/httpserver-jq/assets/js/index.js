let oBtn = document.getElementById("btn")
oBtn.onclick = function(){
    // alert("btn clicked");
    //1.创建对象
    let xhr = new XMLHttpRequest()
    //2.设置请求路径
    xhr.open('GET','/get_data') //普通方法
    // xhr.open('GET','/get_data'+Math.random()) //使得每一次请求都不一样,随机数方法
    // xhr.open('GET','/get_data'+new Date().getTime()) //使得每一次请求都不一样，时间戳方法
    //3.绑定监听状态改变的事件处理函数
    xhr.onreadystatechange = ()=>{
        //  console.log(xhr.readyState); //会输出3个值，分别是2，3，4因为只要状态改变这个函数都能够监听到
        if(xhr.readyState==4 && xhr.status === 200){
            console.log(xhr.responseText);
            //把内容渲染到div
            let content = document.getElementById("content")
            content.innerHTML = xhr.responseText
        }
    }
    //4.发送请求
    //4.1 关闭缓存功能,不是必须的
    xhr.setRequestHeader('Cache-Control','no-cache')
    //4.2 发送请求
    xhr.send()
}