function createAjax(){
    let xhr
    try {
         xhr = new XMLHttpRequest()
    } catch (error) { //ie浏览器
         xhr = new ActiveXObject('microsoft.XMLHttp')
    }
   return xhr
}

let ajax = createAjax()
console.log(ajax);


