let fs = require('fs')
let path = require('path')
let util = require('util')

let filePath1 = path.join(__dirname,"files/client.txt")
let filePath2 = path.join(__dirname,"files/secret.txt")
let filePath3 = path.join(__dirname,"files/info.txt")


const readFile = util.promisify(fs.readFile) //util.promisify可以把一个异步函数变为一个返回Promise的函数

let p1 = readFile(filePath1,"utf-8")
let p2 = readFile(filePath2,"utf-8")
let p3 = readFile(filePath3,"utf-8")

Promise.all([p1,p2,p3]).then(data=>{
    //这里的data是一个数组，包含每一个Promise对象的数据
    // console.log(data);
    console.log(data.join('\r\n'));
})