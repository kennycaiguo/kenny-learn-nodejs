let fs = require('fs')
let path = require('path')

let filePath1 = path.join(__dirname,"files/client.txt")
let filePath2 = path.join(__dirname,"files/secret.txt")
let filePath3 = path.join(__dirname,"files/info.txt")

function getPromise(filepath){
    return new Promise((resolve,reject)=>{
        fs.readFile(filepath,"utf8",(err,data)=>{
        if(err){
            reject(err)
        }
        resolve(data)
      })
    })
}
let p1 = getPromise(filePath1)
let p2 = getPromise(filePath2)
let p3 = getPromise(filePath3)

//拼接
let content = ''
p1.then(data=>{
    content += data + '\r\n'
    return p2
}).then(data=>{
    content += data + '\r\n'
    return p3
}).then(data=>{
    content += data
    console.log('final data:\n',content);
})

 