let fs = require('fs')
let path = require('path')

let filePath1 = path.join(__dirname,"files/client.txt")
let filePath2 = path.join(__dirname,"files/secret.txt")
let filePath3 = path.join(__dirname,"files/info.txt")


async function joinData(filePath1,filePath2,filePath3){
     let str = ''
     let data1 = await new Promise((resolve,reject)=>{
        fs.readFile(filePath1,"utf8",(err,data)=>{
        if(err){
            reject(err)
        }
        resolve(data)
      })
    })

     let data2 = await new Promise((resolve,reject)=>{
        fs.readFile(filePath2,"utf8",(err,data)=>{
        if(err){
            reject(err)
        }
        resolve(data)
      })
    })
     let data3 = await new Promise((resolve,reject)=>{
        fs.readFile(filePath3,"utf8",(err,data)=>{
        if(err){
            reject(err)
        }
        resolve(data)
      })
    })
    // console.log(data1);
    str = data1 + '\r\n' +data2 + '\r\n' + data3
    console.log('joined data:\n',str);
    fs.writeFile('./files/result.txt',str,err=>{
        if(err){
            console.log(err);
            return;
        }
        console.log('saved result in file with success...');
    })
}

joinData(filePath1,filePath2,filePath3)