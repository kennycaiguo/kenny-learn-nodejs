//async ... await的await是异步的
let fs = require('fs')
let path = require('path')
let util = require('util')

let filePath1 = path.join(__dirname,"files/client.txt")
let filePath2 = path.join(__dirname,"files/secret.txt")
// let filePath2 = path.join(__dirname,"files/client.txt")
let filePath3 = path.join(__dirname,"files/info.txt")

const readFile = util.promisify(fs.readFile) //util.promisify可以把一个异步函数变为一个返回Promise的函数

async function testGetData(filePath1,filePath2,filePath3){
 
     let data1 = await readFile(filePath1,"utf-8")
     console.log(data1);
     let data2 = await readFile(filePath2,"utf-8")
     console.log(data2);
     let data3 = await readFile(filePath3,"utf-8")
     console.log(data3);
}

// 外部捕获异常
testGetData(filePath1,filePath2,filePath3).catch(err=>{
    console.log(err);
}).finally(()=>{
    console.log("finally,done...");
})

//内部异常处理
async function testGetData2(filePath1,filePath2,filePath3){
    try {
        let data1 = await readFile(filePath1,"utf-8")
        console.log(data1);
        let data2 = await readFile(filePath2,"utf-8")
        console.log(data2);
        let data3 = await readFile(filePath3,"utf-8")
        console.log(data3);
    } catch (error) {
        console.log(error);
    }finally{
        console.log('finally...');
    }
    
}

// testGetData2(filePath1,filePath2,filePath3)