let fs = require('fs')
let path = require('path')
let util = require('util')

let filePath = path.join(__dirname,"files/result2.txt")
let filePath1 = path.join(__dirname,"files/client.txt")
let filePath2 = path.join(__dirname,"files/secret.txt")
let filePath3 = path.join(__dirname,"files/info.txt")


const readFile = util.promisify(fs.readFile) //util.promisify可以把一个异步函数变为一个返回Promise的函数

let p0 = readFile(filePath,"utf-8")
let p1 = readFile(filePath1,"utf-8")
let p2 = readFile(filePath2,"utf-8")
let p3 = readFile(filePath3,"utf-8")

Promise.race([p1,p2,p3]).then(data=>{ //race方法只要由一个Promise对象执行完成，就会结束
    //这里的data包含执行完成那个个Promise对象的数据
    console.log(data);
})