let fs = require('fs')
let path = require('path')

let filePath1 = path.join(__dirname,"files/client.txt")
let filePath2 = path.join(__dirname,"files/secret.txt")
let filePath3 = path.join(__dirname,"files/info.txt")

let p1 = new Promise((resolve,reject)=>{
    fs.readFile(filePath1,"utf8",(err,data)=>{
    if(err){
        reject(err)
    }
    resolve(data)
  })
})

//拼接
let content = ''

p1.then(data=>{
    // console.log(data);
    content += data + '\r\n'
    return new Promise((resolve,reject)=>{
        fs.readFile(filePath2,"utf8",(err,info)=>{
        if(err){
            reject(err)
        }
        resolve(content+info + '\r\n')
      })
    })
}).then(data2=>{
    return  new Promise((resolve,reject)=>{
        fs.readFile(filePath3,"utf8",(err,data)=>{
        if(err){
            reject(err)
        }
        resolve(data2 + data)
      })
    })
}).then(data3=>{
    console.log("data:" ,data3);
    fs.writeFile("content.txt",data3,(err)=>{
        if(err){
            console.log(err);
            return
        }
        console.log("write file succeeded...");
    })
})

