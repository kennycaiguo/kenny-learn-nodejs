async function getAsyncData() {
    let data = await 12345
    return data
}

let ret = getAsyncData()
console.log(ret);
ret.then(data=>{
    console.log('data:',data);
})