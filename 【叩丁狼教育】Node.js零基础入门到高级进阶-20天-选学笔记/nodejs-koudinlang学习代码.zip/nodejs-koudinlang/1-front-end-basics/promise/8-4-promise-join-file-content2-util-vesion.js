let fs = require('fs')
let path = require('path')
let util = require('util')

let filePath1 = path.join(__dirname,"files/client.txt")
let filePath2 = path.join(__dirname,"files/secret.txt")
let filePath3 = path.join(__dirname,"files/info.txt")

const readFile = util.promisify(fs.readFile) //util.promisify可以把一个异步函数变为一个返回Promise的函数

async function joinData(filePath1,filePath2,filePath3){
     let str = ''
     let data1 = await readFile(filePath1)
     let data2 = await readFile(filePath2)
     let data3 = await readFile(filePath3)

    // console.log(data1);
    str = data1 + '\r\n' +data2 + '\r\n' + data3
    console.log('joined data:\n',str);
    fs.writeFile('./files/result3.txt',str,err=>{
        if(err){
            console.log(err);
            return;
        }
        console.log('saved result in file with success...');
    })
}

joinData(filePath1,filePath2,filePath3)