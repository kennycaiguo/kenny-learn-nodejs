//Promise的基本使用
let fs = require('fs')
let path = require('path')

let filePath = path.resolve(__dirname,"files","test.txt") //路径拼接

// 使用Promise
let p = new Promise((resolve,reject)=>{
    fs.readFile(filePath,"utf8",(err,data)=>{
    if(err){
        reject(err)
    }
    resolve(data)
  })
})

p.then(data=>{
    console.log('data',data);
}).catch(err=>{
    console.log(err);
})