//Promise的基本使用
let fs = require('fs')
let path = require('path')

let filePath = path.resolve(__dirname,"files","test.txt") //路径拼接

// 使用Promise
let p = new Promise((resolve,reject)=>{
    fs.readFile(filePath,"utf8",(err,data)=>{
    if(err){
        reject(err)
    }
    resolve(data)
  })
})

//写法1
// p.then(data=>{
//     console.log('data',data);
// }).catch(err=>{
//     console.log(err);
// })

//写法2
// p.then((data)=>{
//     console.log("data:",data);
//     return "file data:" + data
// },(err)=>{
//     console.log("error:",err);
//     console.log("==================================");
//     return {
//         result:'failed',
//         error:err
//     }
// }).then((data)=>{
//     console.log("the second then func...");
//     console.log("data from the first then func:",data);
// })

//then里面返回Promise对象的情况
p.then((data)=>{
    console.log("data:",data);
    return p
},(err)=>{
    console.log("error:",err);
    console.log("==================================");
    return {
        result:'failed',
        error:err
    }
}).then((data)=>{
    console.log("the second then func...");
    console.log("data from the first then func:",data);
})