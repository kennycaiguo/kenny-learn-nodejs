let fs = require('fs')
let path = require('path')
let util = require('util')

let filePath1 = path.join(__dirname,"files/client.txt")
let filePath2 = path.join(__dirname,"files/secret.txt")
let filePath3 = path.join(__dirname,"files/info.txt")


const readFile = util.promisify(fs.readFile) //util.promisify可以把一个异步函数变为一个返回Promise的函数

let p1 = readFile(filePath1)
let p2 = readFile(filePath2)
let p3 = readFile(filePath3)

//拼接
let content = ''
p1.then(data=>{
    content += data + '\r\n'
    return p2
}).then(data=>{
    content += data + '\r\n'
    return p3
}).then(data=>{
    content += data
    console.log('final data:\n',content);
})

 