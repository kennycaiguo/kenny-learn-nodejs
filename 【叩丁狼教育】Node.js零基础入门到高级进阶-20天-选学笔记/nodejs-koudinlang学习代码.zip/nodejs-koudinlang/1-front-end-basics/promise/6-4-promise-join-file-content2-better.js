let fs = require('fs')
let path = require('path')

let filePath1 = path.join(__dirname,"files/client.txt")
let filePath2 = path.join(__dirname,"files/secret.txt")
let filePath3 = path.join(__dirname,"files/info.txt")

function getPromise(filepath){
  return new Promise((resolve,reject)=>{
      fs.readFile(filepath,"utf8",(err,data)=>{
      if(err){
          reject(err)
      }
      resolve(data)
    })
  })
}

async function joinData(filePath1,filePath2,filePath3){
     let str = ''
     let data1 = await getPromise(filePath1)
     let data2 = await getPromise(filePath2)
     let data3 = await getPromise(filePath3)

    // console.log(data1);
    str = data1 + '\r\n' +data2 + '\r\n' + data3
    console.log('joined data:\n',str);
    fs.writeFile('./files/result2.txt',str,err=>{
        if(err){
            console.log(err);
            return;
        }
        console.log('saved result in file with success...');
    })
}

joinData(filePath1,filePath2,filePath3)