// import {name,age} from './m1' //对应m1中的第1，2种导出
// console.log(`name:${name}\n age:${age}`);
import info ,{gender} from './m1' //对应m1中的第3种导出

console.log(`name:${info.name}\n age:${info.age}`);
console.log("gender:",gender);