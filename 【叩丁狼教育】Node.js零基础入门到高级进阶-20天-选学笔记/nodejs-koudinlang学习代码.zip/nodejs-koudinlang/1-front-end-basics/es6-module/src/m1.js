//第一种方式
// export let name = 'nodejs';
// export let age = 11;

//第二种方式
// let name = 'nodejs'; 
// let age = 11;

// export {name,age}

//第三种默认导出export default，只能由一个而且导入的时候可以改名字
let name = 'nodejs'; 
let age = 11;

export default {name,age}
export let gender = 'Male'